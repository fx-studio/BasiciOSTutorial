//
//  API.Manager.swift
//  DemoNetworking
//
//  Created by Le Phuong Tien on 12/17/19.
//  Copyright © 2019 Fx Studio. All rights reserved.
//

import Foundation

struct APIManager {
    //MARK: Config
    struct Path {
        
    }
    
    //MARK: - Domain
    struct Music {}
    
    struct Downloader {}
}
